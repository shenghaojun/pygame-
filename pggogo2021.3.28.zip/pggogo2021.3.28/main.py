# 程序入口脚本结构
from pgGOGO import *

def main():
    # 创建运行所需的管理类
    gm = GameManager()
    im = InputManager()
    rm = ResourceManager()


    Label()



    # 游戏更新的主循环 
    while True:
        pass
        rm.Update()
        im.Update()
        gm.Update(60)

if __name__ == '__main__':
    main()
