from win32 import win32api, win32gui, win32print
from win32.lib import win32con
from win32.win32api import GetSystemMetrics
from pygame.locals import *
import os
import sys
import pygame


class GameManager(object):
    '''
    游戏管理类\n
    - 一个游戏中只能出现一个GM管理类\n
    - 在你创建游戏时会同时生成一个pygame窗口\n
    - w 游戏窗口的宽度 默认800\n
    - h 游戏窗口的高度 默认600\n
    - title 游戏窗口的标题 默认pygame
    '''
    instance = None
    init = False

    # 构造函数
    def __new__(cls, *args, **kwargs):
        if cls.instance is None:
            cls.instance = super().__new__(cls)

        return cls.instance

    # 初始化函数
    def __init__(self, w: int=800, h: int=600, title: str='pygame', maxsize=False):
        '''
           
        '''

        if GameManager.init: # 只能初始化一次
            return
        GameManager.init = True



        self.playSceneID = 1
        self.quit = True
        self.stop = False
        self.width = w
        self.height = h
        self.flags = 0
        if maxsize:
            self.width,self.height = self.get_real_resolution()
            self.flags = pygame.FULLSCREEN
        
        self.modules = []   # 保存游戏中所有的类对象
        
        pygame.init()
        self.screen = pygame.display.set_mode((self.width,self.height), self.flags)
        pygame.display.set_caption(title)
        self.clock = pygame.time.Clock()


    def get_real_resolution(self):
        """获取真实的分辨率"""
        hDC = win32gui.GetDC(0)
        # 横向分辨率
        w = win32print.GetDeviceCaps(hDC, win32con.DESKTOPHORZRES)
        # 纵向分辨率
        h = win32print.GetDeviceCaps(hDC, win32con.DESKTOPVERTRES)
        return w, h


    def get_screen_size():
        """获取缩放后的分辨率"""
        w = GetSystemMetrics (0)
        h = GetSystemMetrics (1)
        return w, h

    def SetCaption(self, title, icontitle=None):
        pygame.display.set_caption(title, icontitle=None)

    def AddModule(self, name, module):
        '''
        加入类模块
        '''
        if self.FindModule(name) == False:
            print(self.FindModule(name))
            temp_module = GameModule(name, module)
            self.modules.append(temp_module)

    def GetModule(self, name):
        '''
        获得类模块对象
        '''
        for module in self.modules:
            if module.name == name:
                return module.module

        return None

    def FindModule(self, name):
        for module in self.modules:
            if module.name == name:
                return True
        return False
        
    def GameStop(self):
        '''游戏在暂停和继续之间的切换开关'''
        if self.stop:
            self.stop = False
        else:
            self.stop = True

    def GameExit(self):
        '''关闭游戏'''
        self.quit = False

    def SetWindowSize(self, w=800, h=600, flags=HWSURFACE | DOUBLEBUF | RESIZABLE):
        '''
            设置游戏窗口大小
            游戏的所有UI组件会随着地图的尺寸而发生改变
            默认模式为 HWSURFACE | DOUBLEBUF | RESIZABLE
        '''
        self.scree = pygame.display.set_mode((w,h), flags)
        

    def SetSceneID(self, sceneid:int, clear:bool=False, clearid:int=1):
        '''
        切换场景\n
        sceneid 切换到下一个场景的场景编号\n
        clear 切换场景时是否清空旧场景的所有对象\n
        clearid 清空场景的编号\n
        '''
        if clear:
            SceneManager().ClearScene(clearid)

        self.playSceneID = sceneid

    def Update(self, fps):
        if GameManager().stop is not True:
            pygame.display.update()
            self.clock.tick(fps)
        
                


        