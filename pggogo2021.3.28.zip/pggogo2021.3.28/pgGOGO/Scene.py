from pgGOGO.Layer import Layer

class Scene():
    def __init__(self, id:int):
        '''
        所有的场景内都有最基础的两个层，一个是游戏层，一个是ui层
        
        AddLayer 在场景中加入新的层
        FindLayer 在场景中查找层
        '''
        
        self.layers = {}
        self.id = id    # 该场景的编号
        self.AddLayer('root')

    def FindLayer(self, name):
        '''查找层'''
        if self.layers[name] == None:
            return None
        return self.layers[name]

    def AddLayer(self, name):
        '''在创建中添加层'''
        if name not in self.layers.keys():
            self.layers[name] = Layer(name)
        