import pygame
from pgGOGO.SceneManager import SceneManager
from pgGOGO.Scene import Scene
# 资源类，资源的属性和功能都在这里实现

class Resource(pygame.sprite.Sprite):

    def __init__(self, imagePath='', pos=(0,0), name='', parent='', z=0, sceneid=1, visible=True):
        '''
        初始化资源 -> sprite\n
        imagepath 图片的绝对路径\n
        pos 图片显示的初始坐标\n
        name 加入的精灵组组名\n
        z 这个精灵组的渲染地位(先渲染和渲染),默认为0表示直接插入最后
        sceneid 出现在哪个场景
        visible 是否显示
        '''
        pygame.sprite.Sprite.__init__(self)

        # 这个精灵的名字
        self.name = name

        self.imagepath = imagePath
        
        # 加载图片
        try:
            self.image = self.ChangeSpriteType(imagePath)
        except:
            if isinstance(imagePath, pygame.surface.Surface):
                self.image = imagePath

        # 拷贝一份原图
        self.image_copy = self.image.copy()

        # 备份最初始坐标
        self.pos_copy = pos

        # 图片的矩形区域
        self.rect = self.image.get_rect()

        # 图片的初始坐标
        self.rect.x, self.rect.y = pos

        # 图片的碰撞盒
        self.mask = pygame.mask.from_surface(self.image)

        # 资源的默认朝向为方向向右
        self.dirction = 'right'

        # 图片资源的显示顺序，类似于3D近大远小的深度
        self.z = z

        # 这个资源图片所属的场景id
        self.sceneid = sceneid

        # 碰撞到的所有目标都会在这里
        self.collideList = []

        # 是否显示
        self.visible = visible

        # 把资源加入到对应的场景中，并加入对应的精灵组
        if visible:
            # 查找要加入的场景
            scene = SceneManager().FindScene(sceneid)
            # 放在哪个层级下
            layer = scene.FindLayer('root')
            #if layer == None:
            #    layer = scene.FindLayer('root')
            layer.AddGroup('1',self)
    
    def SetVisible(self, visible):
        '''
        设置显示/隐藏精灵
        '''
        if visible:
            self.visible = True
            if self.alive():
                return
            self.add(ResourceManager().FindGroup(self.tag))
        else:
            self.visible = False
            if self.alive():
                self.remove(ResourceManager().FindGroup(self.tag))
    
    def init(self):
        pass

    def Look(self, pos, offset):
        '''
        让对象看向某个点
        pos: 目标的坐标点
        offset: 偏移角度(如果设置的角度不准就填写这个参数去校准)
        '''
        self.image = self.image_copy

        # 得到弧度
        x = pos[0] - self.rect.x
        y = pos[1] - self.rect.y
        radian = math.atan2(y, x)
        # 弧度转换成角度
        angle = math.degrees(radian) - offset
        # 得到旋转之后的图像
        newSurface = pygame.transform.rotate(self.image, angle)
        # 得到旋转后的矩形
        newRect = newSurface.get_rect(center=self.rect.center)
        # 给精灵替换旋转后的图片
        self.image = newSurface
        # 给精灵替换旋转后的矩形
        self.rect = newRect

    def HeightLight(self):
        '''
        图片高亮显示
        '''
        pass

    def Reset(self):
        '''
        图片颜色还原，用于按钮被抬起时的回到原来的图片样式，在按钮事件时添加会更加逼真，可加可不加
        '''
        self.image = self.image_copy.copy()

    def DarkLight(self):
        '''
        图片变暗显示，用于按钮被按下时的特效表现，在按钮事件时添加会更加逼真，可加可不加
        '''
        colorImage = pygame.Surface(self.image.get_size()).convert_alpha()
        colorImage.fill((125,125,125))
        self.image.blit(colorImage, (0,0), special_flags = pygame.BLEND_RGBA_MULT)

    def SetPosition(self, x, y):
        '''
        设置图片的坐标\n
        x 图片的x坐标\n
        y 图片的y坐标\n
        '''
        self.rect.x, self.rect.y = x,y

    def SetZ(self, z:int, isSort:bool=True):
        '''
        设置精灵在组内的渲染顺序，z值越大在组内的渲染越靠后\n
        [注意：使用后组内所有精灵会被重新按自身的z值排序]\n

        z 重新设置绘制顺序z\n
        issort 重新排序\n
        '''
        self.z = abs(z)
        if isSort:
            ResourceManager().SortSpritGroup(self.tag)

            # 精灵被排序，关系到它的点击事件会不会被穿透等一系列原因，所以事件响应也需要排序
            InputManager().MouseClickSorted()

    def CollideCheck(self, tag:str):
        '''
        单个碰撞检查
        tag 与哪个精灵组进行碰撞检测
        '''
        return pygame.sprite.spritecollideany(self, ResourceManager().FindGroup(tag))

    def CollidelistCheck(self, group_list:list):
        '''
        群体碰撞检测
        '''
        if len(group_list) == 0:
            return

        for group in group_list:
            tempGroup = ResourceManager().FindGroupBySceneID(group, GameManager().playSceneID)
            splist = pygame.sprite.spritecollide(self, tempGroup.group, False)
            if splist:
                for sp in splist:
                    self.collideList.append(sp)
                

    def SetSceneID(self, id:int):
        '''
        设置这个精灵资源所属的场景，精灵在创建初期就加入了默认1号场景\n
        使用此函数可以重置它所属的场景\n
        id 加入场景的编号
        '''
        self.sceneid = abs(id)

        ResourceManager().AddGroup(self, self.tag, self.z, self.sceneid)

        ResourceManager().RemoveSprite(self, self.tag)

    def Filp(self, xbool=True, ybool=False):
        '''
        水平翻转还是垂直翻转\n
        xbool 为真时水平翻转\n
        ybool 为真时垂直翻转
        '''
        temp = pygame.transform.flip(self.image,xbool,ybool)
        self.image = temp

    def Scale(self, w, h):
        '''
        缩放图像
        w 缩放的宽度
        h 缩放的高度
        '''
        self.image = pygame.transform.scale(self.image_copy, (w, h))

    def Rotate(self, angle):
        '''
        旋转图像\n
        angle 旋转的角度
        '''
        temp = pygame.transform.rotate(self.image, angle)
        self.image = temp
        
    def Move(self, x, y, border:bool=False, collide:list=None):
        '''
        移动偏移量 -> bool 是否移动成功
        - x：向x坐标移动多少单位
        - y：向y坐标移动多少单位
        - border：是否允许移动到屏幕外
        - collide：碰撞检测的列表['组名','组名'...]
        '''
        self.collideList.clear()
        if border==False:
            if self.rect.left + x < 0 or self.rect.right + x > GameManager().width:
                x = 0
            if self.rect.top + y < 0 or self.rect.bottom + y > GameManager().height:
                y = 0

        if x == 0 and y == 0:   # 动都没动就直接返回移动失败
            return False
        
        if collide: # 开启碰撞检测
            self.CollidelistCheck(collide)

        self.rect.x += x
        self.rect.y += y

    def Home(self):
        '''
        坐标重置为创建此对象时的坐标
        '''
        self.rect.x, self.rect.y = self.pos_copy

    def ChangeSpriteType(self, path):
        '''
        从路径中得到图片流并转成表面对象
        '''
        image = pygame.image.load(os.path.join(r'{0}'.format(path))).convert_alpha()
        return image
    