from pgGOGO import *

class FontManager(object):
    '''
    字体管理类\n
    '''
    instance = None
    init = False

    # 构造函数
    def __new__(cls, *args, **kwargs):
        if cls.instance is None:
            cls.instance = super().__new__(cls)

        return cls.instance

    # 初始化函数
    def __init__(self):
        if FontManager.init: # 只能初始化一次
            return
        
        FontManager.init = True
        
        self.fonts = {}

    def AddFontObject(self, font):
        self.fonts[font.text] = font

    def GetFontByText(self, text:str):
        '''
        根据文本找到字体对象
        '''
        for key, value in self.fonts.keys():
            if key == text:
                return value

    def BandFontToTarget(self, target, font):
        '''
        将字体对象的坐标跟随目标
        target 跟随的目标
        font 字体对象
        '''
        self.fonts[font] = target
                


        