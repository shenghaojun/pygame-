import pygame
from pygame.locals import *
from pgGOGO.GamaManager import GameManager
from pgGOGO.ResourceManager import ResourceManager

class InputManager(object):
    '''
    输入管理
    监听事件
    '''
    instance = None
    init = False


    def __new__(self, *args, **kwargs):
        '''
                构造函数
            只能存在一个对象
        '''
        if self.instance is None:
            self.instance = super().__new__(self)
        return self.instance
    def __init__(self):
        '''
            初始化时只能初始化一次
        '''
        if InputManager.init:
            return
        InputManager.init = True
        MOUSEENTER = pygame.USEREVENT+1
        MOUSEOUT = pygame.USEREVENT+1

        self.m_Key = []
        self.m_Mouse = []
        self.m_Enter = []

    def Update(self):
        '''
        获取pygame的事件
        对所有注册了事件监听的精灵做事件检测
        '''
    
        for event in pygame.event.get():
            # 游戏退出
            if event.type == pygame.QUIT:   
                pygame.quit()
                sys.exit()
            # 如果屏幕尺寸发生改变
            if event.type == VIDEORESIZE:
                # 获得当前屏幕的宽高
                width, height = event.size[0], event.size[1]
                # 窗口尺寸不能小于800x600
                if width < 800 or height < 600:
                    width = 800
                    height = 600
                # 得到缩放倍数
                times_x = (width - GameManager().width) / GameManager().width
                times_y = (height - GameManager().height) / GameManager().height
                # 记录当前窗口尺寸
                GameManager().width = width
                GameManager().height = height
                # 资源缩放
                GameManager().SetWindowSize(width, height)
                ResourceManager().AdaptationScreen(times_x, times_y)

                
            # 键盘按下
            if event.type == pygame.KEYDOWN or event.type == pygame.KEYUP:
                for dic in self.m_Key:
                    if dic['value'].keyclick == False:
                        continue
                    if event.type == pygame.KEYDOWN:
                        if dic['sceneid'] == GameManager().playSceneID:
                            dic['value'].OnKeyDown(event)
                            break
                    else:
                        if dic['sceneid'] == GameManager().playSceneID:
                            dic['value'].OnKeyUp(event)
                            break
            # 鼠标按下与抬起
            if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.MOUSEBUTTONUP:
                for dic in self.m_Mouse:
                    if dic['value'].mouseclick == False:
                        continue
                    if dic['value'].rect.collidepoint(event.pos) and dic['sceneid'] == GameManager().playSceneID:
                        if event.type == pygame.MOUSEBUTTONDOWN:
                            dic['value'].OnMouseDown(event)
                            break
                        else:
                            dic['value'].OnMouseUp(event)
                            break
            # 鼠标滚轮
            if event.type == pygame.MOUSEWHEEL:
                for dic in self.m_Mouse:
                    if dic['sceneid'] == GameManager().playSceneID:
                        dic['value'].OnMouseWheel()

        # 持续按键事件
        keys = pygame.key.get_pressed()
        for dic in self.m_Key:
            if dic['value'].keyclick == False:
                continue
            if dic['sceneid'] == GameManager().playSceneID:
                dic['value'].OnKey(keys)
                break

        # 鼠标进入事件
        for dic in self.m_Mouse:
            if dic['value'].mouseclick == False:
                continue
            if dic['value'].rect.collidepoint(pygame.mouse.get_pos()) and dic['sceneid'] == GameManager().playSceneID:
                dic['value'].OnMouseEnter(pygame.mouse.get_pos())
                dic['enter'] = True
                break
            else:
                if dic['enter']:
                    dic['value'].OnMouseOut(pygame.mouse.get_pos())
                    dic['enter'] = False
                break
                        

    def MouseClickSorted(self):
        for i in self.m_Mouse:
            i['z'] = i['value'].z
        self.m_Mouse = sorted(self.m_Mouse, key = lambda i: i['z'], reverse=True)
    
    def AddKeyListener(self, key, obj):
        '''
        添加键盘按键监听
        key 注册类的名字
        obj 注册的类的对象
        '''
        dic = {}
        dic['key'] = key
        dic['value'] = obj
        dic['sceneid'] = obj.sceneid
        
        self.m_Key.append(dic)

    def DelKeyListener(self, key):
        pass

    def GetKeyListener(self, key):
        pass

    def AddMouseListener(self, key, mouselistener):
        '''
        添加鼠标按键监听
        z 鼠标点击事件需要z深度来决定当很多对象重叠在一起时点到的第一个对象是谁
        key  注册类的名字
        mouselistener 注册的类的对象
        '''
        dic = {}
        dic['z'] = mouselistener.z
        dic['key'] = key
        dic['value'] = mouselistener
        dic['sceneid'] = mouselistener.sceneid
        dic['enter'] = False
        self.m_Mouse.append(dic)
        self.MouseClickSorted()

    def DelMouseListener(self, key):
        pass

    def GetMouseListener(self, key):
        pass