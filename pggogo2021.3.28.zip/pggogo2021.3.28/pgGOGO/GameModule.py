from pgGOGO import *

class GameModule(object):
    def __init__(self, name, module):
        
        self.name = name

        self.module = module