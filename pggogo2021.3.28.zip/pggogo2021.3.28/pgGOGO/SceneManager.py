from pgGOGO.Scene import Scene

class SceneManager(object):
    '''
    场景管理类\n
    '''
    instance = None
    init = False

    # 构造函数
    def __new__(cls, *args, **kwargs):
        if cls.instance is None:
            cls.instance = super().__new__(cls)

        return cls.instance

    # 初始化函数
    def __init__(self):
        if SceneManager.init: # 只能初始化一次
            return
        
        SceneManager.init = True
        
        self.scenes = []
        self.CreateScene(1)

    def CreateScene(self, id):
        '''
        创建一个新场景\n
        如果这个场景id，如果这个场景存在就返回这个场景对象\n
        id = 这个场景的id\n
        '''
        scene = Scene(id)
        self.scenes.append(scene)
        return scene

    def ClearScene(self, sceneid):
        '''
        清空场景中所有的精灵组\n
        sceneid 场景编号\n
        '''
        self.FindScene(sceneid).Groups.clear()

    def RemoveSceneGroupByName(self, sceneid, groupname):
        '''
        移除场景中指定名称的精灵组\n
        sceneid 场景编号\n
        groupname 待移除的精灵组的组名\n

        # 未开发\n
        '''
        #scene = self.FindScene(sceneid)

    def FindScene(self, id):
        '''
        根据id查找场景对象
        '''
        for scene in self.scenes:
            if scene.id == id: 
                return scene

        # 如果没有这个id的场景就创建一个
        return self.CreateScene(id)
        