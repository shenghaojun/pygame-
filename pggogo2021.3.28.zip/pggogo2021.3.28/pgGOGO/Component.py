from pgGOGO import *

class Component(object):
    '''
    组件类，组件的通用属性
    此类通常只用来继承，不能作为对象
    '''
    align = ''

    def Center(self, image:pygame.sprite.Sprite , font:pygame.sprite.Sprite):
        '''
        将字体的坐标对齐到图片的中心点\n
        image 图片精灵\n
        font 字体精灵
        '''
        diff_x = image.image.get_width() - font.image.get_width()
        diff_y = image.image.get_height() - font.image.get_height()
        if diff_x >= 0:
            font.rect.x = image.rect.x + diff_x / 2
        if diff_y >= 0: 
            font.rect.y = image.rect.y + diff_y / 2

    def Left(self, image:pygame.sprite.Sprite , font:pygame.sprite.Sprite):
        font.rect.x = image.rect.x

    def Right(self, image:pygame.sprite.Sprite , font:pygame.sprite.Sprite):
        font.rect.x = image.rect.x + image.image.get_width()

    def Up(self, image:pygame.sprite.Sprite , font:pygame.sprite.Sprite):
        font.rect.y = image.rect.y

    def Bottom(self, image:pygame.sprite.Sprite , font:pygame.sprite.Sprite):
        font.rect.y = image.rect.y + image.image.get_height()
        

