import pygame


class Layer():
    '''
        层次层
        一个层内有许多的精灵组
    '''        

    def __init__(self, name):
        
        #self.image = Resource(r'pgGOGO\image\Layout.png') if imagepath == None else Resource(imagepath)
        self.name = name
        self.groups = {}


    def AddGroup(self, group_name, obj):
        if group_name not in self.groups.keys():
            g = pygame.sprite.Group(obj)
            self.groups[group_name] = g
            return

        self.groups[group_name].add(obj)
            
    def FindGroup(self, group_name):
        if group_name in self.groups.keys():
            return self.groups[group_name]

        print('Layer内不存在[{0}]精灵组'.format(group_name))
        
    def GetWidth(self):
        return self.image.get_width()

    def GetWidth(self):
        return self.image.get_height()

    def SetSize(self, w, h):
        self.image.Scale(w, h)

    
        