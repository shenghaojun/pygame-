from pgGOGO import *

class pgGOGO(Enum):
    UI_LAYER = 1
    