import pygame
from pgGOGO.Resource import Resource
from pgGOGO.GamaManager import GameManager
from pgGOGO.SceneManager import SceneManager

class ResourceManager(object):
    '''
    管理所有的资源
    '''
    instance = None
    init = False

    def __new__(cls, *args, **kwargs):
        if cls.instance is None:
            cls.instance = super().__new__(cls)

        return cls.instance

    def __init__(self):
        if ResourceManager.init:
            return

        ResourceManager.init = True

        # 得到屏幕对象
        self.screen = GameManager().screen

        # 所有的精灵组
        self.m_groups = []

        # 绘制网格参数
        self.m_show_grid = False
        self.m_grid_row = 2
        self.m_grid_column = 2
        self.m_width = 5
        self.m_height = 5
        self.m_grid_pos = (0,0)
        self.m_grid_color = (255, 0, 0)
        # 绘制矩形参数
        self.m_show_rect = False
        self.m_rect_width = 0
        self.m_rect_pos = (0,0)
        self.m_Rect = (50,50,50,50)


    def FindFilesTodict(self, path):
        print(os.listdir(path))    
    
    # ---------------------- 下面是关于所有精灵组的操作函数----------------------------
    def AddGroup(self, sprite):
        '''
        sprite 待加入的精灵

        根据精灵自身的标签和出演的场景决定他所加入的精灵组
        '''
        # 1 寻找要加入的场景
        scene = SceneManager().FindScene(sprite.sceneid)

        # 2 根据自己的标签加入对应的层
        #if sprite.parent:
            # 如果是ui就加入ui层
        #    scene.UILayer.AddGroup(sprite.,sprite)

        # 如果没有找到精灵组就重新创建一个并加入精灵
        if temp_group is None:
            ag = ActorGroup(name)
            ag.group.add(sprite)
            self.m_groups.append(ag)
            # 从场景管理中的找到对应的场景加入新的精灵组
            SceneManager().FindScene(sceneid).AddGroup(ag)
        else: 
            temp_group.group.add(sprite)

        if z != 0: # 如果加入的精灵有深度需求，对组内成员排序
            self.SortSpritGroup(name)

    def AdaptationScreen(self, w, h):
        for aggroup in self.m_groups:
            for sp in aggroup.group.sprites():
                for base in sp.__class__.__bases__:
                    if base.__name__ == 'MultiFrameImage':
                        sp.AdaptationScreen(w, h)
                    elif base.__name__ == 'Button':
                        sp.AdaptationScreen(w, h)
                    elif base.__name__ == 'Label':
                        sp.AdaptationScreen(w, h)
                    elif sp.base.__name__ == 'CFont':
                        sp.AdaptationScreen(w, h)
                if sp.__class__.__name__ == 'MultiFrameImage':
                    sp.AdaptationScreen(w, h)
                elif sp.__class__.__name__ == 'Button':
                    sp.AdaptationScreen(w, h)
                elif sp.__class__.__name__ == 'Label':
                    sp.AdaptationScreen(w, h)
                elif sp.__class__.__name__ == 'CFont':
                    sp.AdaptationScreen(w, h)

    def SortSpritGroup(self, group_name:str=''):
        '''排序精灵组成员的渲染顺序'''
        templist = []
        agGroup = self.FindGroup(group_name)
        for sp in agGroup.group.sprites():
            tempdict = {}
            tempdict['z'] = sp.z
            tempdict['obj'] = sp
            templist.append(tempdict)
        templist = sorted(templist, key = lambda i: i['z'])

        # 2 清空精灵组
        agGroup.group.empty()

        # 3 将排序好的重新放回精灵组中
        for dic in templist:
            agGroup.group.add(dic['obj'])

    def FindGroup(self, name:str=None):
        '''
        根据场景编号寻找出演的精灵组\n
        return True
        name = 精灵组的名称
        '''
        for group in self.m_groups:
            if group.name == name:
                return group.group
            
        return None

    def ClearGroupByName(self, groupname):
        '''
        清空指定精灵组名的精灵组的所有精灵
        '''
        group = self.FindGroup(groupname)
        if group is None:
            return None
        for sp in group.sprites():
            group.remove(sp)

    def FindSprite(self, sprite: pygame.sprite.Sprite, grup_name=None):
        if group_name is not None:
            gp = FindGroup(group_name)
            for sp in gp.sprite():
                if sp == sprite:
                    return sp

    def RemoveSprite(self, sprite, group):
        self.FindGroup(group).group.remove(sprite)

    def FindGroupBySceneID(self, name:str, sceneid:int=1):
        '''
        根据场景编号寻找出演的精灵组\n
        return ActorGroup
        name = 精灵组的名称
        '''
        # 得到参加编号场景的所有精灵组列表
        scene = SceneManager().FindScene(sceneid)
        # 遍历每个精灵组，匹配名字
        for agGroup in scene.Groups:
            if agGroup.name == name:
                return agGroup
                
        return None

    def SurfaceTransfromSprite(self, target, pos):
        '''
        将表面对象转换成精灵对象
        '''
        sp = pygame.sprite.Sprite()
        sp.image = target
        sp.rect = sp.image.get_rect()
        sp.rect.x, sp.rect.y = pos
        return sp


    # ----------------------下面是关于绘制网格的所有函数--------------------------
    def SetGrid(self, color:tuple=(255,0,0), pos:tuple=(0,0), row:int=2, column:int=2, width:int=5, height:int=5):
        '''
        绘制一个网格
        color 网格的颜色
        row 网格的行数
        column 网格的列数
        size 网格的大小
        '''
        self.m_grid_color = color
        self.m_grid_row = row
        self.m_grid_column = column
        self.m_grid_width = width
        self.m_grid_height = height
        self.m_grid_pos = pos

    def GetShow(self):
        '''获取当前网格是否显示'''
        return self.m_show_grid

    def ShowGrid(self):
        '''开启网格是否显示'''
        self.m_show_grid = True
    
    def QuitGrid(self):
        '''关闭网格显示'''
        self.m_show_grid = False

    def GetGridPointData():
        '''测试用  请无视'''
        x, y = 0
        for i in range(self.m_grid_row + 1):
            x = self.m_grid_pos[0] + 0
            y = self.m_grid_pos[1] + i * self.m_grid_height

            pygame.draw.line(self.screen, self.m_grid_color, 
                            (self.m_grid_pos[0] + 0,  self.m_grid_pos[1] + i * self.m_grid_height), 
                            (self.m_grid_pos[0] + self.m_grid_column * self.m_grid_width, self.m_grid_pos[1] + i * self.m_grid_height))

        for i in range(self.m_grid_column + 1):
                pygame.draw.line(self.screen, self.m_grid_color, 
                                (self.m_grid_pos[0] + i * self.m_grid_width, self.m_grid_pos[1] + 0), 
                                (self.m_grid_pos[0] + i * self.m_grid_width, self.m_grid_pos[1] + self.m_grid_row * self.m_grid_height))

    # 每次切换场景都会调用这个场景所有演员的初始化
    def ResourceInit(self, sceneid):
        for scene in SceneManager().scenes:
                if scene.id == sceneid:
                    for group in scene.Groups:
                        for sp in group.group.sprites():
                            sp.init()

    def DrawRect(self, rect):
        self.m_Rect = rect

    # -----------------下面是所有对象的渲染---------------------
    # 包括是否绘制网格测试显示
    def Update(self):
        '''
        资源渲染
        '''
        if GameManager().stop is not True:
            self.screen.fill((255,255,255))

            for scene in SceneManager().scenes:
                if scene.id == GameManager().playSceneID:
                    for layer in scene.layers.values():
                        for group in layer.groups.values():
                            group.update()
                            group.draw(self.screen)
                        
            if self.m_show_grid:
                for i in range(self.m_grid_row + 1):
                    pygame.draw.line(self.screen, self.m_grid_color, 
                                    (self.m_grid_pos[0] + 0,  self.m_grid_pos[1] + i * self.m_grid_height), 
                                    (self.m_grid_pos[0] + self.m_grid_column * self.m_grid_width, self.m_grid_pos[1] + i * self.m_grid_height))

                for i in range(self.m_grid_column + 1):
                    pygame.draw.line(self.screen, self.m_grid_color, 
                                    (self.m_grid_pos[0] + i * self.m_grid_width, self.m_grid_pos[1] + 0), 
                                    (self.m_grid_pos[0] + i * self.m_grid_width, self.m_grid_pos[1] + self.m_grid_row * self.m_grid_height))

            if self.m_show_rect:
                pygame.draw.rect(self.screen, (255,0,0), self.m_Rect, 1)

        
                

