from pgGOGO import *

class ActorGroup(object):
    def __init__(self, name='NoName'):

        self.group = pygame.sprite.Group()

        self.name = name