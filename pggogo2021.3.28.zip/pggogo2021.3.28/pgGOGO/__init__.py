
# 本框架所有的类都需要使用 [from pgGOGO import *] 语句
# 即可直接调用使用下列所有的模块，如有需要请自行添加
# 框架结构为：

# 1. 管理类
# GamaManager     游戏管理类
# ResourceManager 资源管理类
# InputManager    输入管理类
# SceneManager    场景管理类
# FontManager     字体管理类

# 2. 组件类
# Resource                资源类
#     Button              按钮组件
#     Animation           动画组件
#     StaticFrameImage    静态图片组件
#     MultiFrameImage     动态图片组件
#     CFont               字体类
#       Label             标签组件
# Component               基础控件类

# 3. 事件
# Listener.KeyListener    键盘事件监听
# Listener.MouseListener  鼠标事件监听

# 4. 数据存储
# Scene       场景数据类型
# ActorGroup  演员组数据类
# GameModule  类模块数据

#import pygame
#from pygame.locals import *
#from Pinyin2Hanzi import DefaultDagParams
#from Pinyin2Hanzi import dag
#import os
#import sys
#import random
#import copy
#import math
#import tkinter

#from win32 import win32api, win32gui, win32print
#from win32.lib import win32con
#from win32.win32api import GetSystemMetrics


#from enum import Enum

from pgGOGO.GamaManager import GameManager
from pgGOGO.SceneManager import SceneManager
from pgGOGO.ResourceManager import ResourceManager
from pgGOGO.InputManager import InputManager
from pgGOGO.FontManager import FontManager
from pgGOGO.AudioManager import AudioManager

from pgGOGO.UI import *

try:
    import pgGOGO.GamaManager
except (ImportError, IOError):
    print('游戏管理类不存在')

try:
    import pgGOGO.SceneManager
except (ImportError, IOError):
    print('场景管理类不存在')

try:
    import pgGOGO.ResourceManager
except (ImportError, IOError):
    print('资源管理类不存在')

try:
    import pgGOGO.InputManager
except (ImportError, IOError):
    print('输入管理类不存在')

try:
    import pgGOGO.FontManager
except (ImportError, IOError):
    print('字体管理类不存在')

try:
    import pgGOGO.AudioManager
except (ImportError, IOError):
    print('音效管理类不存在')

#from .ActorGroup import ActorGroup
#from .Scene import Scene
#from .GameModule import GameModule

#from .AudioManager import AudioManager
#from .SceneManager import SceneManager
#from .GamaManager import GameManager
#from .ResourceManager import ResourceManager
#from .FontManager import FontManager
#from .InputManager import InputManager

#from .Resource import Resource
#from .Layer import Layer
#from .Component import Component
#from .Listener import KeyListener
#from .Listener import MouseListener
#from .StaticFrameImage import StaticFrameImage
#from .MultiFrameImage import MultiFrameImage
#from .Animation import Animation

#from .Frame import Frame
#from .CFont import CFont
#from .Button import Button
#from .Label import Label
#from .TextBox import TextBox



