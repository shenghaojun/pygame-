from pgGOGO.UI.Font import Font

class Label(Font):
    '''
    返回一个标签对象
    - font：后缀名为ttf的字体路径
    - size：标签的大小
    - color：标签的颜色
    - background：标签的背景色
    - text：标签的文本
    - pos：标签的坐标
    - group：标签的精灵组
    - z：标签的渲染顺序
    - sceneid：标签的演出场景编号
    - visible：是否显示标签
    '''
    def __init__(self, name='', font='pgGOGO/font/simkai.ttf', size=16, color=(0,0,0), background=None, text='Label', pos=(0,0), group='ui', z=0, sceneid=1, visible=True):
        super(Label, self).__init__(name=name, font=font, size=size, color=color, background=background, text=text, pos=pos, group=group, z=z, sceneid=sceneid, visible=visible)

    def AdaptationScreen(self, w, h):
        tw = int(self.image.get_width() * w + self.image.get_width())
        th = int(self.image.get_height() * h + self.image.get_height())
        self.Scale(tw, th)
        self.rect.x += int(self.rect.x * w)
        self.rect.y += int(self.rect.y * h)

    