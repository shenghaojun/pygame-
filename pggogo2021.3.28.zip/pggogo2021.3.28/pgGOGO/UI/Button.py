from pgGOGO.Listener import KeyListener
from pgGOGO.Listener import MouseListener
from pgGOGO.Resource import Resource

class Button(Resource, KeyListener, MouseListener):
    '''
        按钮组件,父级如下\n
        Resource 资源类的图片属性\n
        KeyListener 按键事件监听\n
        MouseListener 鼠标事件监听\n

        参数介绍：\n
        imagepath   按钮显示的图片，如果不填默认使用框架的按钮图片\n
        pos         按钮的显示坐标，如果不填默认为(0,0)\n
        text        按钮上显示的文字， 如果不填默认为不显示任何文字\n
        tag  按钮加入的精灵组的名字，如果不填默认加入ui精灵组\n
        z           按钮在精灵组的绘制顺序，z越小越早被绘制，容易被别的精灵挡住\n
        sceneid     按钮在第几个场景会被绘制出来, 如果不写默认在第一个场景就被绘制\n
    '''
    def __init__(self, imagepath:str=None, pos:tuple=(0,0), text:str=None, size:int=12, name='', color:tuple=(0,0,0), parent=None, z:int=0, sceneid:int=1):
        '''
            参数介绍：\n
            imagepath   按钮显示的图片，如果不填默认使用框架的按钮图片\n
            pos         按钮的显示坐标，如果不填默认为(0,0)\n
            text        按钮上显示的文字， 如果不填默认为不显示任何文字\n
            tag  按钮加入的精灵组的名字，如果不填默认加入ui精灵组\n
            z           按钮在精灵组的绘制顺序，z越小越早被绘制，容易被别的精灵挡住\n
            sceneid     按钮在第几个场景会被绘制出来, 如果不写默认在第一个场景就被绘制\n
        '''
        # 调用资源类的图片属性
        if imagepath is not None:
            super(Button, self).__init__(imagepath, (0,0), name, ui, z, sceneid)
        else:
            super(Button, self).__init__(r'pgGOGO\image\button.png', (0,0), name,  ui, z, sceneid)
        
        self.keyclick = True
        self.mouseclick = True
        self.font = None
        self.text = text
        self.font_x = 0
        self.font_y = 0

        if self.text is not None:
            # 得到字体精灵
            self.font = CFont(text=text, color=color, size=size, name=name, group=tag, z=z, sceneid=sceneid, visible=False)
            self.SetFontAglin()
            self.DarwText((self.font_x, self.font_y))
        self.rect.x, self.rect.y = pos

    def AdaptationScreen(self, w, h):
        tw = int(self.image.get_width() * w + self.image.get_width())
        th = int(self.image.get_height() * h + self.image.get_height())
        self.Scale(tw, th)
        self.rect.x += int(self.rect.x * w)
        self.rect.y += int(self.rect.y * h)

    def SetFontAglin(self):
        '''
        设置字体对其方式
        '''
        # 计算居中的位置
        if self.font is not None:
            diff_x = self.image.get_width() - self.font.image.get_width()
            diff_y = self.image.get_height() - self.font.image.get_height()
            self.font_x = diff_x / 2
            self.font_y = diff_y / 2

    def DarwText(self, pos):
        '''
        1. 将字体画在按钮上的某个坐标内\n
        2. 将字体和按钮图片进行融合成为新的带字体的按钮
        '''
        if self.font is not None:
            
            self.image.blit(self.font.image, pos)
            self.image_copy = self.image.copy()
        
    def ChangeFontText(self, text):
        '''
        修改字体显示的文本
        '''
        if self.font is not None:
            self.image = self.ChangeSpriteType(self.imagepath)
            self.font.ChangeText(text)
            self.SetFontAglin()
            
            self.DarwText((self.font_x, self.font_y))
        

