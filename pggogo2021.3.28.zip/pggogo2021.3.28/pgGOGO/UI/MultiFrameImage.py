from pgGOGO.Resource import Resource

class MultiFrameImage(Resource):
    '''
    多帧图类，用于播放连续帧动画
    '''
    def __init__(self, files=None, pos:tuple=(0,0), name='', playspeed:int=24, play:bool=True, group:str='UI', z=0, sceneid=1):
        '''
        继承多帧图时，初始化需要的必要属性\n
        files 图片集，需要得到存放图片列表的集合\n
        pos = 初始坐标 默认为左上角0，0\n
        playspeed 图片的播放速度， 默认为2的播放速度\n
        playone = 图片动画是否只播放一次，默认为播放一次\n
        group = 加入的精灵组，默认加入UI精灵组
        '''
        
        if files == None:
            files = r'pgGOGO\image\MultiFrameImage'
        # 播放图片集的字典
        self.images = []
        self.files = os.listdir(files)
        for file in self.files:
            text = r'{0}\{1}'.format(files, str(file))
            self.images.append(text)

        self.images_copy = self.images

        # 播放一次的开关
        self.play = play

        # 播放速度
        self.playspeed = playspeed

        # 播放计时
        self.playTimer = 0

        # 当前播放的第几帧
        self.current_frame = 0

        # 最大帧
        self.max_frame = len(self.images)

        
        super(MultiFrameImage, self).__init__(self.images[0], pos, name, group, z, sceneid)

        # 将所有的图片路径转化成表面对象
        for i in range(len(self.images)):
            self.images[i] = self.ChangeSpriteType(self.images[i])

    def AdaptationScreen(self, w, h):
        timages = []
        for image in self.images_copy:
            # 得到缩放比
            tw = int(image.get_width() * w + image.get_width())
            th = int(image.get_height() * h + image.get_height())
            # 对图片组进行缩放
            image = pygame.transform.scale(image, (tw, th))
            timages.append(image)
        self.images = timages
        self.rect.x += int(self.rect.x * w)
        self.rect.y += int(self.rect.y * h)

    def update(self):
        if self.play:
            self.Play()

    def Stop(self):
        self.play = False

    def Play(self):
        '''
        playTimer 内置计时器每秒加1，并跟角色的播放速度playspeed进行比较
        如果计时器等于播放速度，就表示要切换下一张图片了

        current_frame 和 max_frame 在切换图片时会比较
        如果当前播放的帧数已经等于最大播放的帧数了，就回到第一帧，达到循环
        '''
        if self.playTimer == self.playspeed:
            if self.current_frame == self.max_frame:
                self.current_frame = 0
            self.current_frame += 1
            self.playTimer = 0
            
            # 得到当前播放的动作的图片集合
            self.image = self.images[self.current_frame - 1]
        self.playTimer += 1

        
        