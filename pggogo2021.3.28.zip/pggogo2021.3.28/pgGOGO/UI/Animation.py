from pgGOGO.Resource import Resource

class Animation(Resource):
    '''
    动作类，用于播放帧动画\n
    当一个对象有多组的动画序列帧时继承这个类即可\n
    只需传入每个动作帧存放文件的路径\n
    会自动读取里面的序列帧并生成一组动画\n
    这个动画组的名字为文件夹名\n
    '''
    def __init__(self, filespath:list, pos:tuple=(0,0), playspeed:int=30, name='', group:str='unit', z:int=0, sceneid=1):
        '''
        继承多帧图时，初始化需要的必要属性\n
        filespath 动作文件夹集合路径，传入存有一连串动作图片的文件夹名\n
        自动转化为动态图 如['walk','attack',...]\n
        pos = 初始坐标 默认为左上角0，0\n
        playspeed 图片的播放速度， 默认为30的播放速度\n
        playone = 图片动画是否只播放一次，默认为播放一次\n
        group = 加入的精灵组，默认加入单位精灵组
        '''
        # animation字典
        # key保存动作的名字
        # value保存动作的序列帧图片路径
        self.animations = {}
        for file in filespath:
            paths = os.listdir(file)
            new_paths = []
            for path in paths:
                text = r'{0}\{1}'.format(str(file), path)
                new_paths.append(text)
            self.animations[str(file)] = new_paths

        # 设置默认的动作名字
        self.default_animation_name = list(self.animations.keys())[0]

        # 当前播放的动作名字
        self.animation_name = self.default_animation_name

        # 播放速度
        self.playspeed = playspeed

        # 播放计时
        self.playTimer = 0

        # 当前播放的第几帧
        self.current_frame = 0

        # 当前播放的图片
        self.current_play_image = None

        # 最大帧
        self.max_frame = len(self.animations[self.animation_name])

        # 调用父类Resource资源类的初始化，传入需要第一张显示的精灵
        super(Animation, self).__init__(self.animations[self.animation_name][0],pos, name, group, z, sceneid)

        # 将所有序列帧图片路径转化为表面对象
        temp_dic = {}
        for key, value in self.animations.items():
            temp_list = []
            temp_list = [self.ChangeSpriteType(path)  for path in value]
            temp_dic[key] = temp_list

        self.animations = temp_dic

    def PlayAnimation(self, animation_name:str, frame:int=0):
        '''
        让对象播放指定动作名所属动作帧\n
        animation_name 动作名（保存动作帧的文件夹名）\n
        frame 这个动作从第几帧开始播放\n
        '''
        self.animation_name = animation_name
        self.max_frame = len(self.animations[animation_name])
        if frame is not 0:
            if self.max_frame < frame:
                frame = self.max_frame - 1
            self.current_frame = frame
            

    def update(self):
        self.Play()

    def Play(self):
        '''
        1. playTimer 内置计时器每秒加1，并跟角色的播放速度playspeed进行比较
        如果计时器等于播放速度，就表示要切换下一张图片了

        2. current_frame 和 max_frame 在切换图片时会比较
        如果当前播放的帧数已经等于最大播放的帧数了，就回到第一帧，达到循环

        3. 播放默认的动作名的组，如果动作被切换播放，播放完毕回到默认动作

        4. 根据dirction参数控制是否需要让角色水平翻转
        '''
        if self.playTimer == self.playspeed:
            if self.current_frame == self.max_frame:
                # 当前动画的所有帧都播放完毕
                # 判断当前播放的动画是不是默认动画，如果不是切换回默认播放动画
                if self.default_animation_name is not self.animation_name:
                    self.animation_name = self.default_animation_name
                    self.max_frame = len(self.animations[self.animation_name])
                self.current_frame = 0
            self.current_frame += 1
            self.playTimer = 0
                
            # 得到当前播放的动作的图片集合
            images = self.animations[self.animation_name]
            self.current_play_image = images[self.current_frame - 1]

            # 动画的朝向，根据dirction参数控制是否需要水平翻转
            if self.dirction is 'left':
                self.image = pygame.transform.flip(self.current_play_image,True,False)
            else:
                self.image = self.current_play_image
            
        self.playTimer += 1