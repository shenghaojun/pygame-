import pygame
from pgGOGO.Resource import Resource


class Font(Resource):
    def __init__(self, font='pgGOGO/font/simkai.ttf',size=16, name='', color=(0,0,0), background=None, text='Font', pos=(0,0), group='font',z=0, sceneid=1, visible=True):
        
        # 的到文字的表面对象
        font = pygame.font.Font(font, size).render(text, True, color, background)

        # 调用父类的初始化，变为精灵对象
        super(Font, self).__init__(imagePath=font, pos=pos, name=name, z=z, sceneid=sceneid, visible=visible)
        
        # 保存字体
        self.font = font

        # 保存文本 
        self.text = text

        # 保存字体的大小
        self.size = size

        # 保存字体的颜色
        self.color = color

        # 保存字体的背景色
        self.background = background

    def AdaptationScreen(self, w, h):
        tw = int(self.image.get_width() * w + self.image.get_width())
        th = int(self.image.get_height() * h + self.image.get_height())
        self.Scale(tw, th)
        self.rect.x += int(self.rect.x * w)
        self.rect.y += int(self.rect.y * h)

    # 修改字体
    def ChangeText(self, text, font='pgGOGO/font/simkai.ttf', size=None, color=None, background=None):
        if font is not None:
            self.font = font
        if size is not None:
            self.size = size
        if color is not None:
            self.color = color
        if background is not None:
            self.background = background

        font = pygame.font.Font(font, self.size)
        sur = font.render(str(text), True, self.color, self.background)
        self.text = text
        self.image = sur