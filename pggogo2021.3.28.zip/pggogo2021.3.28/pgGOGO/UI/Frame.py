from pgGOGO import *

class Frame():
    '''
        多个组件组合的窗口
    '''

    def __init__(self, tbg=None, wbg=None):
        
        
        self.window_bg = Resource(r'pgGOGO\image\frame_window_bg.png') if wbg == None else Resource(wbg)
        self.title_bg = Resource(r'pgGOGO\image\frame_title_bg.png') if tbg == None else Resource(tbg)
        self.title_bg.SetZ(1)

    def GetWidth(self):
        return self.image.get_width()

    def GetWidth(self):
        return self.image.get_height()

    def SetSize(self, w, h):
        self.image.Scale(w, h)