from pgGOGO.Resource import Resource

class StaticFrameImage(Resource):
    '''
    静态图片类 只能用来生成静态图片
    '''

    def __init__(self, imagepath=None, pos=(0,0), name='', group='UI', z=0, sceneid=1):
        '''
        静态图片类 只能用来生成静态图片\n
        imagepath = 生成的图片的绝对路径，不填则使用框架提供的图片\n
        pos = 生成图片的初始坐标\n
        group = 图片所处的精灵组的名字，跟后续渲染和碰撞有关，默认为UI精灵\n
        z = 图片在组内的渲染顺序\n
        sceneid = 图片在哪个场景才会被渲染
        '''
        if imagepath is None:
            super(StaticFrameImage, self).__init__(r'pgGOGO\image\StaticImage.png', pos, name,  group, z, sceneid)
        else:
            super(StaticFrameImage, self).__init__(imagepath, pos, name, group, z, sceneid)

        
        
        

        