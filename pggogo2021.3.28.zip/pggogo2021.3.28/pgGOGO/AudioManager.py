from pgGOGO import *

class AudioManager(object):
    '''
    音频管理类\n
    '''
    instance = None
    init = False

    # 构造函数
    def __new__(cls, *args, **kwargs):
        if cls.instance is None:
            cls.instance = super().__new__(cls)

        return cls.instance

    # 初始化函数
    def __init__(self):
        if AudioManager.init: # 只能初始化一次
            return

        self.audios = {}
        self.Load('cilck', 'pgGOGO/audio/click.ogg')

    def Load(self, name:str, file:str):
        self.audios[name] = file
        
    def Play(self, name):
        for key, value in self.audios.items():
            if key == name:
                pygame.mixer.music.load(value)
                pygame.mixer.music.play()