from pgGOGO import *

class KeyListener(object):
    
    '''
    键盘事件监听
    '''
    def __init__(self):
        pass

    def OnKeyDown(self, event):
        '''
        键位被按下事件
        '''
        pass
    
    def OnKeyUp(self, event):
        '''
        键位被抬起事件
        '''
        pass

    def OnKey(self, keys):
        '''
        这个按键事件在按下时会一直执行
        '''
    def ExitKeyListener(self):
        self.keyclick = False

    def OpenKeyListener(self):
        self.keyclick = True

class MouseListener(object):

    '''
    鼠标事件监听
    '''
    def __init__(self):
        pass

    def OnMouseDown(self, event):
        '''
        鼠标被按下事件
        '''
        pass

    def OnMouseUp(self, event):
        '''
        鼠标被抬起事件
        '''
        pass

    def OnMouseEnter(self, pos):
        '''
        鼠标进入对象
        '''
        pass

    def OnMouseOut(self, pos):
        '''
        鼠标离开对象
        '''
        pass

    def OnMouseWheel(self, event):
        '''
        鼠标滚轮事件
        '''
        pass

    def ExitMouseListener(self):
        self.mouseclick = False

    def OpenMouseListener(self):
        self.mouseclick = True